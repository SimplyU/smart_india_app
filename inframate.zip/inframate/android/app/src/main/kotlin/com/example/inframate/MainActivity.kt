package com.example.inframate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
